<?php
/**
 * 联系方式管理API
 * 支持获取、添加、删除联系人的多种联系方式
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 引入数据库配置
$configFile = dirname(__DIR__) . '/config/database.php';
if (!file_exists($configFile)) {
    die(json_encode([
        'success' => false,
        'message' => '配置文件不存在'
    ]));
}
require_once $configFile;

try {
    $db = DatabaseManager::getInstance();
    $method = $_SERVER['REQUEST_METHOD'];
    
    // GET - 获取联系人的所有联系方式
    if ($method === 'GET') {
        if (!isset($_GET['contact_id'])) {
            throw new Exception('缺少联系人ID');
        }
        
        $contactId = intval($_GET['contact_id']);
        $sql = "SELECT * FROM contact_methods WHERE contact_id = ? ORDER BY id ASC";
        $methods = $db->query($sql, [$contactId]);
        
        echo json_encode([
            'success' => true,
            'data' => $methods
        ], JSON_UNESCAPED_UNICODE);
    }
    
    // POST - 添加联系方式
    elseif ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['contact_id'])) {
            throw new Exception('缺少联系人ID');
        }
        
        if (empty($input['method_type'])) {
            throw new Exception('缺少联系方式类型');
        }
        
        if (empty($input['method_value'])) {
            throw new Exception('缺少联系方式值');
        }
        
        // 验证联系方式类型
        $validTypes = ['phone', 'email', 'wechat', 'qq', 'weibo', 'address'];
        if (!in_array($input['method_type'], $validTypes)) {
            throw new Exception('无效的联系方式类型');
        }
        
        $sql = "INSERT INTO contact_methods (contact_id, method_type, method_value, label) VALUES (?, ?, ?, ?)";
        $params = [
            $input['contact_id'],
            $input['method_type'],
            $input['method_value'],
            isset($input['label']) ? $input['label'] : null
        ];
        
        $insertId = $db->execute($sql, $params);
        
        if ($insertId) {
            echo json_encode([
                'success' => true,
                'message' => '添加成功',
                'id' => $insertId
            ], JSON_UNESCAPED_UNICODE);
        } else {
            throw new Exception('添加失败');
        }
    }
    
    // DELETE - 删除联系方式
    elseif ($method === 'DELETE') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['id'])) {
            throw new Exception('缺少联系方式ID');
        }
        
        $sql = "DELETE FROM contact_methods WHERE id = ?";
        $result = $db->execute($sql, [$input['id']]);
        
        if ($result > 0) {
            echo json_encode([
                'success' => true,
                'message' => '删除成功'
            ], JSON_UNESCAPED_UNICODE);
        } else {
            throw new Exception('删除失败或记录不存在');
        }
    }
    
    else {
        throw new Exception('不支持的请求方法');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

