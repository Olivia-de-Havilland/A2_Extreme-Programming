<?php
/**
 * 导出通讯录为Excel文件
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

// 引入数据库配置
$configFile = dirname(__DIR__) . '/config/database.php';
if (!file_exists($configFile)) {
    die(json_encode([
        'success' => false,
        'message' => '配置文件不存在'
    ]));
}
require_once $configFile;

try {
    $db = DatabaseManager::getInstance();
    
    // 获取所有联系人
    $sql = "SELECT * FROM contacts ORDER BY is_favorite DESC, id DESC";
    $contacts = $db->query($sql);
    
    if (empty($contacts)) {
        throw new Exception('没有可导出的联系人');
    }
    
    // 创建CSV内容（使用CSV格式，Excel可以打开）
    $filename = 'contacts_' . date('YmdHis') . '.csv';
    $filepath = sys_get_temp_dir() . '/' . $filename;
    
    $fp = fopen($filepath, 'w');
    
    // 添加BOM以支持中文
    fprintf($fp, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // 写入表头
    $headers = ['ID', '姓名', '主电话', '主邮箱', '地址', '备注', '是否收藏', '创建时间', '更新时间'];
    fputcsv($fp, $headers);
    
    // 写入数据
    foreach ($contacts as $contact) {
        // 获取该联系人的所有额外联系方式
        $methodsSql = "SELECT method_type, method_value, label FROM contact_methods WHERE contact_id = ?";
        $methods = $db->query($methodsSql, [$contact['id']]);
        
        $row = [
            $contact['id'],
            $contact['name'],
            $contact['phone'],
            $contact['email'] ?: '',
            $contact['address'] ?: '',
            $contact['notes'] ?: '',
            $contact['is_favorite'] ? '是' : '否',
            $contact['created_at'],
            $contact['updated_at']
        ];
        
        // 如果有额外联系方式，添加到备注中
        if (!empty($methods)) {
            $methodsText = [];
            foreach ($methods as $method) {
                $label = $method['label'] ? "({$method['label']})" : '';
                $type = [
                    'phone' => '电话',
                    'email' => '邮箱',
                    'wechat' => '微信',
                    'qq' => 'QQ',
                    'weibo' => '微博',
                    'address' => '地址'
                ][$method['method_type']] ?? $method['method_type'];
                $methodsText[] = "{$type}{$label}: {$method['method_value']}";
            }
            $row[5] .= ($row[5] ? ' | ' : '') . '额外联系方式: ' . implode('; ', $methodsText);
        }
        
        fputcsv($fp, $row);
    }
    
    fclose($fp);
    
    // 读取文件内容并返回base64编码
    $fileContent = file_get_contents($filepath);
    $base64Content = base64_encode($fileContent);
    
    // 删除临时文件
    unlink($filepath);
    
    echo json_encode([
        'success' => true,
        'filename' => $filename,
        'content' => $base64Content,
        'count' => count($contacts)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

