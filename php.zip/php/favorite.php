<?php
/**
 * 收藏功能API
 * 切换联系人的收藏状态
 */

// 设置字符编码
mb_internal_encoding('UTF-8');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 引入数据库配置
$configFile = dirname(__DIR__) . '/config/database.php';
if (!file_exists($configFile)) {
    die(json_encode([
        'success' => false,
        'message' => '配置文件不存在'
    ]));
}
require_once $configFile;

try {
    // 只接受POST请求
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('请求方法错误');
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (empty($input['id'])) {
        throw new Exception('缺少联系人ID');
    }
    
    $db = DatabaseManager::getInstance();
    
    // 获取当前收藏状态
    $sql = "SELECT is_favorite FROM contacts WHERE id = ?";
    $contact = $db->fetchOne($sql, [$input['id']]);
    
    if (!$contact) {
        throw new Exception('联系人不存在');
    }
    
    // 切换收藏状态
    $newStatus = $contact['is_favorite'] ? 0 : 1;
    $updateSql = "UPDATE contacts SET is_favorite = ? WHERE id = ?";
    $result = $db->execute($updateSql, [$newStatus, $input['id']]);
    
    if ($result !== false) {
        echo json_encode([
            'success' => true,
            'message' => $newStatus ? '已添加到收藏' : '已取消收藏',
            'is_favorite' => $newStatus
        ], JSON_UNESCAPED_UNICODE);
    } else {
        throw new Exception('操作失败');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

