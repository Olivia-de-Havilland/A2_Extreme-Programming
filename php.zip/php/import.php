<?php
/**
 * 从Excel文件导入通讯录
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 引入数据库配置
$configFile = dirname(__DIR__) . '/config/database.php';
if (!file_exists($configFile)) {
    die(json_encode([
        'success' => false,
        'message' => '配置文件不存在'
    ]));
}
require_once $configFile;

try {
    // 只接受POST请求
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('请求方法错误');
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (empty($input['content'])) {
        throw new Exception('缺少文件内容');
    }
    
    // 解码base64内容
    $fileContent = base64_decode($input['content']);
    if ($fileContent === false) {
        throw new Exception('文件内容解码失败');
    }
    
    // 保存到临时文件
    $tempFile = sys_get_temp_dir() . '/import_' . uniqid() . '.csv';
    file_put_contents($tempFile, $fileContent);
    
    $db = DatabaseManager::getInstance();
    
    // 读取CSV文件
    $fp = fopen($tempFile, 'r');
    if (!$fp) {
        throw new Exception('无法打开文件');
    }
    
    // 跳过表头
    $headers = fgetcsv($fp);
    
    $successCount = 0;
    $failCount = 0;
    $errors = [];
    
    // 逐行读取并导入
    while (($row = fgetcsv($fp)) !== false) {
        try {
            // 至少需要姓名和电话
            if (count($row) < 2) {
                continue;
            }
            
            $name = trim($row[1] ?? '');
            $phone = trim($row[2] ?? '');
            
            if (empty($name) || empty($phone)) {
                $failCount++;
                $errors[] = "第" . ($successCount + $failCount + 1) . "行: 姓名或电话为空";
                continue;
            }
            
            // 验证电话号码格式
            if (!preg_match('/^1[3-9]\d{9}$/', $phone)) {
                $failCount++;
                $errors[] = "第" . ($successCount + $failCount + 1) . "行: 电话号码格式不正确 ({$phone})";
                continue;
            }
            
            // 检查电话号码是否已存在
            $checkSql = "SELECT id FROM contacts WHERE phone = ?";
            $exists = $db->fetchOne($checkSql, [$phone]);
            if ($exists) {
                $failCount++;
                $errors[] = "第" . ($successCount + $failCount + 1) . "行: 电话号码已存在 ({$phone})";
                continue;
            }
            
            $email = trim($row[3] ?? '');
            $address = trim($row[4] ?? '');
            $notes = trim($row[5] ?? '');
            $isFavorite = (isset($row[6]) && $row[6] === '是') ? 1 : 0;
            
            // 插入联系人
            $sql = "INSERT INTO contacts (name, phone, email, address, notes, is_favorite) VALUES (?, ?, ?, ?, ?, ?)";
            $params = [
                $name,
                $phone,
                $email ?: null,
                $address ?: null,
                $notes ?: null,
                $isFavorite
            ];
            
            $insertId = $db->execute($sql, $params);
            
            if ($insertId) {
                $successCount++;
            } else {
                $failCount++;
                $errors[] = "第" . ($successCount + $failCount + 1) . "行: 插入失败";
            }
            
        } catch (Exception $e) {
            $failCount++;
            $errors[] = "第" . ($successCount + $failCount + 1) . "行: " . $e->getMessage();
        }
    }
    
    fclose($fp);
    unlink($tempFile);
    
    echo json_encode([
        'success' => true,
        'message' => "导入完成: 成功 {$successCount} 条, 失败 {$failCount} 条",
        'success_count' => $successCount,
        'fail_count' => $failCount,
        'errors' => array_slice($errors, 0, 10) // 只返回前10个错误
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

